/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tors;

/**
 *
 * @author kim2
 */
class TourPackage {
    // Attributes
    private String packageId;
    private String packageName;
    private String packageDescription;
    private TourDestination destination;
    private double packagePrice;

    // Operations
    public void viewPackageInformation() {
        // Code to display package information
    }
}