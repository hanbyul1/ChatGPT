/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tors;

/**
 *
 * @author kim2
 */
import java.util.ArrayList;
import java.util.List;

public class Database {
//    private static ArrayList<Tour> tours = new ArrayList<Tour>();
//    private static ArrayList<Customer> customers = new ArrayList<Customer>();
//    private static ArrayList<Employee> employees = new ArrayList<Employee>();
//    private static ArrayList<Reservation> reservations = new ArrayList<Reservation>();
//    private static ArrayList<Feedback> feedbacks = new ArrayList<Feedback>();

    private static List<Tour> tours = new ArrayList<>();
    private static List<Customer> customers = new ArrayList<>();
    private static List<Reservation> reservations = new ArrayList<>();
    private static List<Feedback> feedbacks = new ArrayList<>();
    private static List<Employee> employees = new ArrayList<>();

    public Database() {
        tours = new ArrayList<Tour>();
        customers = new ArrayList<Customer>();
        reservations = new ArrayList<Reservation>();
        feedbacks = new ArrayList<Feedback>();
    }

    static void updateTour(Tour tour) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static void updateCustomer(Customer customer) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    static Iterable<Tour> getAllTours() {
        return tours;
    }
        
    public static ArrayList<Tour> getTours() {
        return new ArrayList<Tour>(tours);
    }

    public static ArrayList<Customer> getCustomers() {
        return new ArrayList<Customer>(customers);
    }

    public static ArrayList<Employee> getEmployees() {
        return new ArrayList<Employee>(employees);
    }

    public static ArrayList<Reservation> getReservations() {
        return new ArrayList<Reservation>(reservations);
    }

    public static ArrayList<Feedback> getFeedbacks() {
        return new ArrayList<Feedback>(feedbacks);
    }

    public static boolean addTour(Tour tour) {
        return tours.add(tour);
    }

    public static boolean addCustomer(Customer customer) {
        return customers.add(customer);
    }

    public static boolean addEmployee(Employee employee) {
        return employees.add(employee);
    }

    public static boolean addReservation(Reservation reservation) {
        return reservations.add(reservation);
    }

    public static boolean addFeedback(Feedback feedback) {
        return feedbacks.add(feedback);
    }

    public static boolean removeTour(Tour tour) {
        return tours.remove(tour);
    }

    public static boolean removeCustomer(Customer customer) {
        return customers.remove(customer);
    }

    public static boolean removeEmployee(Employee employee) {
        return employees.remove(employee);
    }

    public static boolean removeReservation(Reservation reservation) {
        return reservations.remove(reservation);
    }

    public static boolean removeFeedback(Feedback feedback) {
        return feedbacks.remove(feedback);
    }

    public static Tour findTour(String tourName) {
        for (Tour tour : tours) {
            if (tour.getName().equals(tourName)) {
                return tour;
            }
        }
        return null;
    }

    public static Customer findCustomer(String customerName) {
        for (Customer customer : customers) {
            if (customer.getName().equals(customerName)) {
                return customer;
            }
        }
        return null;
    }

    public static Employee findEmployee(String employeeName) {
        for (Employee employee : employees) {
            if (employee.getName().equals(employeeName)) {
                return employee;
            }
        }
        return null;
    }

    public static Reservation findReservation(String customerName, String tourName) {
        for (Reservation reservation : reservations) {
            if (reservation.getTour().getName().equals(tourName) && reservation.getCustomer().getName().equals(customerName)) {
                return reservation;
            }
        }
        return null;
    }
}


//public static Reservation findReservation(String customerName, String tourName) {
//    for (Reservation reservation : reservations) {
//        if (reservation.getTour().getName().equals(tourName) && reservation.getCustomer().getName().equals(customerName)) {
//            return reservation;
//        }
//
//public Reservation findReservation(int reservationId) {
//    for (Reservation reservation : reservations) {
//        if (reservation.getReservationId() == reservationId) {
//            return reservation;
//        }
//    }
//    return null;
//}

//private List<Tour> tours = new ArrayList<>();
//private List<Customer> customers = new ArrayList<>();
//private List<Reservation> reservations = new ArrayList<>();
//private List<Feedback> feedbacks = new ArrayList<>();
//
//private List<Tour> tours = new ArrayList<>();
//private List<Customer> customers = new ArrayList<>();
//private List<Reservation> reservations = new ArrayList<>();
//private List<Feedback> feedbacks = new ArrayList<>();
//
//public Database() {
//    tours = new ArrayList<Tour>();
//    customers = new ArrayList<Customer>();
//    reservations = new ArrayList<Reservation>();
//    feedbacks = new ArrayList<Feedback>();
//}
