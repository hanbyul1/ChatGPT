/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tors;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author kim2
 */
class Tour {

    // Attributes
    private String tourId;
    private String tourName;
    private String tourDestination;
    private String tourDescription;
    private String tourLocation;    
    private String tourDuration;
    private String tourPrice;
    private List<Reservation> reservations;    
    private final String tourType;
    private LocalDate startDate;
    private LocalDate endDate;

    public Tour(String tourId, String tourName, String tourType, String tourDestination, String tourDescription, String tourDuration, String tourPrice, LocalDate startDate, LocalDate endDate) {
        this.tourId = tourId;
        this.tourName = tourName;
        this.tourType = tourType;
        this.tourDestination = tourDestination;
        this.tourDescription = tourDescription;
        this.tourDuration = tourDuration;
        this.tourPrice = tourPrice;
        this.reservations = new ArrayList<>();
        this.startDate = startDate;
        this.endDate = endDate;
    }
    // Operations
    public void viewTourInformation() {
        System.out.println("Tour Name: " + tourName);
        System.out.println("Tour Description: " + tourDescription);
        System.out.println("Tour Location: " + tourLocation);
        System.out.println("Tour Price: " + tourPrice);
        System.out.println("Tour Duration: " + tourDuration + " days");
    }
    public boolean makeReservation(Reservation reservation) {
        if (reservations.contains(reservation)) {
            return false;
        }
        return reservations.add(reservation);
    }
    public void updateTourInformation() {
        // Code to update tour information
    }
        public String getName() {
        return tourName;
    }

    public String getLocation() {
        return tourLocation;
    }

    public String getDescription() {
        return tourDescription;
    }

    public String getPrice() {
        return tourPrice;
    }

    String getTourName() {
        return tourName;
    }

    String getTourPrice() {
        return tourPrice;
    }

    public String getStatus() {
        String status;
        if (this.startDate.isAfter(LocalDate.now())) {
            status = "Upcoming";
        } else if (this.endDate.isBefore(LocalDate.now())) {
            status = "Completed";
        } else {
            status = "Ongoing";
        }
        return status;
    }    
    public static ArrayList<Tour> getAvailableTours() {
        ArrayList<Tour> availableTours = new ArrayList<>();
        Iterable<Tour> allTours = Database.getAllTours();  // initialize allTours
        for (Tour tour : allTours) {
            if (tour.getStatus().equals("Upcoming")) {
                availableTours.add(tour);
            }
        }
        return availableTours;
    }

    private class endDate {

        public endDate() {
        }
    }
    
}
