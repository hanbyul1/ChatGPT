/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tors;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author kim2
 */
class Employee {
    // Attributes
    private String employeeId;
    private String employeeName;
    private String employeeEmail;
    private String employeePhone;
    private String loginId;
    private String password;
    private ArrayList<Tour> tours;

    public Employee(String loginId, String password, String name) {
        this.loginId = loginId;
        this.password = password;
        this.employeeName = employeeName;
    }
    
    // Operations
    public boolean login(String loginID, String password) {
        if (this.loginId.equals(loginID) && this.password.equals(password)) {
            return true;
        } else {
            return false;
        }
    }
    public void manageCustomers() {
        // Code to add, delete, and update information on customers
    }
    public void manageTours() {
        // Code to add, delete, and update information on tours
    }
    //The following are added later
    public void addTour(Tour newTour) {
        tours.add(newTour);
    }
    public void updateTour() {
        // Code to update tour
    }
    public void deleteTour() {
        // Code to delete tour
    }
    
    public void addTour(String tourId, String tourName, String tourType, String tourDestination, String tourDescription, String tourDuration, String tourPrice, LocalDate startDate, LocalDate endDate) {
        Tour tour = new Tour(tourId, tourName, tourType, tourDestination, tourDescription, tourDuration, tourPrice, startDate, endDate);
        Database.addTour(tour);
    }

    public void deleteTour(Tour tour) {
        Database.removeTour(tour);
    }

    public void updateTour(String tourId, String tourName, String tourType, String tourDestination, String tourDescription, String tourDuration, String tourPrice, LocalDate startDate, LocalDate endDate) {
        Tour tour = new Tour(tourId, tourName, tourType, tourDestination, tourDescription, tourDuration, tourPrice, startDate, endDate);
        Database.updateTour(tour);
    }

    public void addCustomer(String customerId, String customerName, String customerEmail) {
        Customer customer = new Customer(customerId, customerName, customerEmail);
        Database.addCustomer(customer);
    }

    public void deleteCustomer(Customer customer) {
        Database.removeCustomer(customer);
    }

    public void updateCustomer(String customerId, String customerName, String customerEmail) {
        Customer customer = new Customer(customerId, customerName, customerEmail);
        Database.updateCustomer(customer);
    }

    Object getName() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void confirmReservation(Reservation reservation) {
        System.out.println("Reservation has been confirmed.");
    }

    void saveReservation(Reservation reservation) {
        Database.addReservation(reservation);
    }
}