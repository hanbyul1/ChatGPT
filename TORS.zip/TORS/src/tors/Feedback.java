/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tors;
//The customerName was added by fixing Date
import java.util.Date;

/**
 *
 * @author kim2
 */
class Feedback {
    // Attributes
    private String feedbackId;
    private Customer customer;
    private String feedbackMessage;
    private Date feedbackDate;
    //The customerName was added by fixing Date    
    private String customerName;
        
    //The constructor was added by fixing Date
    public Feedback(String customerName, String feedbackMessage, Date feedbackDate) {
        this.customerName = customerName;
        this.feedbackMessage = feedbackMessage;
        this.feedbackDate = feedbackDate;
    }
        
    // Operations
    public void viewFeedback() {
        // Code to view feedback
    }
    public void sendFeedback() {
        // Code to send feedback
    }    
}
