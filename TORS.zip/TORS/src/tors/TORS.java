/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tors;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author kim2
 */
public class TORS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Tour> tours = new ArrayList<Tour>();
        ArrayList<Customer> customers = new ArrayList<Customer>();
        ArrayList<Reservation> reservations = new ArrayList<Reservation>();
        Scanner sc = new Scanner(System.in);

        Employee employee = new Employee("admin", "password", "Admin");

        // Add tours to the system
        LocalDate startDate = LocalDate.of(2021, Month.JANUARY, 1);
        LocalDate endDate = LocalDate.of(2021, Month.DECEMBER, 31);
        employee.addTour("T1", "Tour 1", "Type 1", "Destination 1", "Description 1", "Duration 1", "Price 1", startDate, endDate);
        startDate = LocalDate.of(2023, Month.JANUARY, 1);
        endDate = LocalDate.of(2023, Month.DECEMBER, 31);
        employee.addTour("T2", "Tour 2", "Type 2", "Destination 2", "Description 2", "Duration 2", "Price 2", startDate, endDate);
        startDate = LocalDate.of(2024, Month.JANUARY, 1);
        endDate = LocalDate.of(2024, Month.DECEMBER, 31);
        employee.addTour("T3", "Tour 3", "Type 3", "Destination 3", "Description 3", "Duration 3", "Price 3", startDate, endDate);

        // Add customers to the system
        employee.addCustomer("C1", "Customer1", "c1@email.com");
        employee.addCustomer("C2", "Customer2", "c2@email.com");
        employee.addCustomer("C3", "Customer3", "c3@email.com");

        // Get the available tours
        tours = Tour.getAvailableTours();

        // Display the available tours
        for (int i = 0; i < tours.size(); i++) {
            System.out.println((i + 1) + ". " + tours.get(i).getTourName());
        }

        // Get the selected tour from the customer
        System.out.print("Enter the number of the tour that you want to book: ");
        int tourNumber = sc.nextInt();
        Tour selectedTour = null;
        if (tours.size() > 0 && tourNumber > 0 && tourNumber <= tours.size()) {
            selectedTour = tours.get(tourNumber - 1);
            // code to book the tour
        } else {
            System.out.println("No tours available to book or invalid tour number entered.");
        }

        // Get the customer information
        System.out.print("Enter the customer name: ");
        String customerName = sc.next();
        Customer customer = Database.findCustomer(customerName);

        if (selectedTour != null) {
            Reservation reservation = new Reservation(selectedTour, customer);
            // code to add the reservation to the system

            // Confirm the reservation
            employee.confirmReservation(reservation);

            // Save the reservation
            employee.saveReservation(reservation);

            // Display the reservation information
            System.out.println("Reservation ID: " + reservation.getReservationId());
            System.out.println("Tour: " + selectedTour.getTourName());
            System.out.println("Customer: " + customer.getCustomerName());
            System.out.println("Price: " + selectedTour.getTourPrice());
        } else {
            System.out.println("Tour not selected. Reservation not created.");
        }
    }    
}
