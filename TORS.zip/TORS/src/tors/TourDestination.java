/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tors;

/**
 *
 * @author kim2
 */
class TourDestination {
    // Attributes
    private String destinationId;
    private String destinationName;
    private String destinationCountry;
    private String destinationContinent;

    // Operations
    public void viewDestinationInformation() {
        // Code to display destination information
    }
}
