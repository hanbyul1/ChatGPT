/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tors;

/**
 *
 * @author kim2
 */
class Customer {

    // Attributes
    private String customerId;
    private String customerName;
    private String customerEmail;
    private String customerPhone;
    private String customerAddress;

    public Customer(String customerId, String customerName, String customerEmail) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerEmail = customerEmail;
    }
    // Operations
    public void viewReservation() {
        // Code to view the customer's existing reservations
    }
    public void cancelReservation() {
        // Code to cancel an existing reservation
    }
    public void sendFeedback() {
        // Code to send feedback to the agency
    }
    //The following are added later
    public void viewCustomerInformation() {
    // Code to display customer information
    }
    public void updateCustomerInformation() {
        // Code to update customer information
    }
    
    public String getName() {
    return customerName;
    }

    public String getEmail() {
        return customerEmail;
    }

    public String getPhoneNumber() {
        return customerPhone;
    }

    public String getAddress() {
        return customerAddress;
    }

    String getCustomerName() {
        return customerName;
    }
}