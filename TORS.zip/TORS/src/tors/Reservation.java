/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tors;
import java.util.Date;
import java.util.List;

/**
 *
 * @author kim2
 */
class Reservation {
    // Attributes
    private int reservationId=0;
    private Tour tour;
    private Customer customer;
    private Date reservationDate;
    private int numberOfPassengers;
    private int numberOfPeople;
    
    private List<Reservation> reservations;

    public Reservation(Tour tour, Customer customer) {
        this.reservationId = reservationId++;
        this.tour = tour;
        this.customer = customer;
        this.reservationDate = new Date();
    }
        
    // Operations
    public void viewReservationDetails() {
        System.out.println("Tour Name: " + tour.getName());
        System.out.println("Tour Location: " + tour.getLocation());
        System.out.println("Tour Description: " + tour.getDescription());
        System.out.println("Tour Price: " + tour.getPrice());
        System.out.println("Customer Name: " + customer.getName());
        System.out.println("Customer Email: " + customer.getEmail());
        System.out.println("Customer Phone Number: " + customer.getPhoneNumber());
        System.out.println("Number of People: " + numberOfPeople);
        System.out.println("Reservation Date: " + reservationDate);
    }
    
    public void cancelReservation() {
        // Code to cancel a reservation
    }
    
    public boolean cancelReservation(Reservation reservation) {
        // Iterate through the list of reservations
        for (int i = 0; i < reservations.size(); i++) {
            // Check if the reservation matches the one passed as an argument
            if (reservations.get(i).equals(reservation)) {
                // Remove the reservation from the list and return true to indicate success
                reservations.remove(i);
                return true;
            }
        }
        // If the reservation is not found, return false to indicate failure
        return false;
    }
       
        public Tour getTour() {
        return tour;
    }

    public Customer getCustomer() {
        return customer;
    }

    public int getNumberOfPeople() {
        return numberOfPeople;
    }

    public Date getReservationDate() {
        return reservationDate;
    }

    int getReservationId() {
        return reservationId;
    }
}